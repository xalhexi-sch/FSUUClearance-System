# FSUU Student Clearance System

A production-oriented Django application for digitizing Father Saturnino Urios University student clearance workflows. The project includes role-based dashboards for students, office staff, registrar/admin users, and system administrators, along with PDF and Excel reporting, audit logs, and demo data for fast evaluation.

## Features
- Secure authentication with lockout protection after five failed attempts
- First-login password change enforcement
- Role-based dashboards and route protection
- Student progress tracking with per-office remarks and PDF export
- Office queue management with bulk approval, filters, and modal actions
- Admin analytics dashboard with charts and export-ready reports
- Audit logging for login, logout, approvals, rejections, and password changes
- Email notifications using Django's configurable email backend
- Bootstrap 5 responsive UI with sidebar navigation and mobile support

## Prerequisites
- Python 3.11+
- MySQL 8.0+
- pip / virtualenv

## Installation
1. Extract the ZIP file.
2. Open a terminal inside `student_clearance_system`.
3. Create and activate a virtual environment:
   ```bash
   python -m venv .venv
   source .venv/bin/activate
   ```
4. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
5. Create a MySQL database named `clearance_system` (or your preferred name).
6. Copy environment variables:
   ```bash
   cp .env.example .env
   ```
7. Update `.env` with your MySQL credentials and set `DB_ENGINE=mysql`.
8. Run migrations:
   ```bash
   python manage.py makemigrations
   python manage.py migrate
   ```
9. Load demo data:
   ```bash
   python manage.py seed_demo_data
   ```
10. Start the development server:
    ```bash
    python manage.py runserver
    ```

> For quick local smoke tests without MySQL, set `DB_ENGINE=sqlite` in `.env`. The codebase still includes full MySQL-ready settings and SQL schema files.

## Default Login Credentials
All seeded accounts use the password `Password123!`.

- Super Admin: `superadmin`
- Admin users: `admin1`, `admin2`, `admin3`
- Sample staff users: `library1`, `clinic1`, `cashier1`, `registrar1`, `guidance1`, `laboratory1`, `academicprogram1`
- Sample student users: `student01` to `student50`

## Project Structure
- `accounts/` - authentication, login workflows, password change enforcement
- `clearance/` - business logic, dashboards, models, admin configuration, seed command
- `reports/` - PDF and Excel export views/utilities
- `database/` - MySQL schema and reference seed SQL
- `static/` and `clearance/static/` - CSS, JavaScript, images

## Usage Guide
### Students
- Sign in with your student account.
- Review your active semester progress and office-level remarks.
- Download the PDF clearance form when fully cleared.

### Office Staff
- Use the office dashboard to filter and review pending requests.
- Update item status through the modal action dialog.
- Use bulk approval for multiple students when appropriate.

### Admin / Registrar
- Review clearance metrics and processing trends on the admin dashboard.
- Open the reports page to filter by semester, office, program, or year level.
- Export reports as PDF or Excel.

### System Administrator
- Access Django admin via `/admin/` for full platform management.
- Manage users, offices, semesters, requests, and audit logs.

## Troubleshooting
- **MySQL connection error**: verify `DB_NAME`, `DB_USER`, `DB_PASSWORD`, `DB_HOST`, and `DB_PORT` in `.env`.
- **`mysqlclient` build issue**: install MySQL development headers and compiler tools before running `pip install -r requirements.txt`.
- **No data appears after login**: run `python manage.py seed_demo_data` and ensure an active semester exists.
- **Password reset emails not sent**: keep the default console backend during development or configure SMTP credentials in `.env`.

## Technologies Used
- Django 5
- Bootstrap 5.3
- Vanilla JavaScript
- MySQL 8
- ReportLab
- OpenPyXL
- Crispy Forms

## Contributors
Prepared for FSUU digital clearance modernization projects.
