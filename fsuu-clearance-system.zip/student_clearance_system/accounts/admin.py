from django.contrib import admin
from django.contrib.auth.admin import UserAdmin

from .models import CustomUser


@admin.register(CustomUser)
class CustomUserAdmin(UserAdmin):
    model = CustomUser
    list_display = ('username', 'email', 'role', 'office', 'is_active', 'must_change_password')
    list_filter = ('role', 'office', 'is_active', 'must_change_password')
    fieldsets = UserAdmin.fieldsets + (
        ('Role Settings', {'fields': ('role', 'office', 'must_change_password', 'failed_login_attempts', 'locked_until')}),
        ('Timestamps', {'fields': ('created_at', 'updated_at')}),
    )
    readonly_fields = ('created_at', 'updated_at')
