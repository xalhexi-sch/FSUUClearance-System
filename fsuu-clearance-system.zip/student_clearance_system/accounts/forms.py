from django import forms
from django.contrib.auth import authenticate
from django.contrib.auth.forms import PasswordChangeForm

from .models import CustomUser


class BootstrapMixin:
    def apply_bootstrap(self):
        for field in self.fields.values():
            css_class = field.widget.attrs.get('class', '')
            field.widget.attrs['class'] = f'{css_class} form-control'.strip()


class LoginForm(forms.Form, BootstrapMixin):
    username = forms.CharField(max_length=150)
    password = forms.CharField(widget=forms.PasswordInput)
    remember_me = forms.BooleanField(required=False)

    def __init__(self, request=None, *args, **kwargs):
        self.request = request
        self.user_cache = None
        super().__init__(*args, **kwargs)
        self.apply_bootstrap()
        self.fields['remember_me'].widget.attrs['class'] = 'form-check-input'

    def clean(self):
        cleaned_data = super().clean()
        username = cleaned_data.get('username')
        password = cleaned_data.get('password')
        if not username or not password:
            return cleaned_data

        user = CustomUser.objects.filter(username=username).first()
        if user and user.is_locked():
            raise forms.ValidationError('This account is temporarily locked due to multiple failed login attempts.')

        self.user_cache = authenticate(self.request, username=username, password=password)
        if self.user_cache is None:
            if user:
                user.register_failed_login()
            raise forms.ValidationError('Invalid username or password.')
        self.user_cache.reset_login_attempts()
        return cleaned_data

    def get_user(self):
        return self.user_cache


class FirstTimePasswordChangeForm(PasswordChangeForm, BootstrapMixin):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.apply_bootstrap()
