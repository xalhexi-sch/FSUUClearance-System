from django.shortcuts import redirect
from django.urls import reverse


class ForcePasswordChangeMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        if request.user.is_authenticated and getattr(request.user, 'must_change_password', False):
            exempt_names = {
                'accounts:change_password',
                'accounts:logout',
                'accounts:password_reset',
                'accounts:password_reset_done',
                'accounts:password_reset_confirm',
                'accounts:password_reset_complete',
            }
            current = request.resolver_match.view_name if request.resolver_match else ''
            if current not in exempt_names and not request.path.startswith('/admin/'):
                return redirect(reverse('accounts:change_password'))
        return self.get_response(request)
