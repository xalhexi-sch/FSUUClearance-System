from datetime import timedelta

from decouple import config
from django.contrib.auth.models import AbstractUser
from django.db import models
from django.utils import timezone


class CustomUser(AbstractUser):
    ROLE_STUDENT = 'student'
    ROLE_OFFICE_STAFF = 'office_staff'
    ROLE_ADMIN = 'admin'
    ROLE_SUPERADMIN = 'superadmin'

    ROLE_CHOICES = [
        (ROLE_STUDENT, 'Student'),
        (ROLE_OFFICE_STAFF, 'Office Staff'),
        (ROLE_ADMIN, 'Registrar/Admin Staff'),
        (ROLE_SUPERADMIN, 'System Administrator'),
    ]

    user_id = models.BigAutoField(primary_key=True)
    role = models.CharField(max_length=20, choices=ROLE_CHOICES, default=ROLE_STUDENT)
    office = models.ForeignKey(
        'clearance.Office',
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='staff_members',
    )
    must_change_password = models.BooleanField(default=True)
    failed_login_attempts = models.PositiveSmallIntegerField(default=0)
    locked_until = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'custom_user'
        ordering = ['username']

    def is_locked(self):
        return bool(self.locked_until and self.locked_until > timezone.now())

    def register_failed_login(self):
        self.failed_login_attempts += 1
        if self.failed_login_attempts >= 5:
            minutes = config('LOCKOUT_MINUTES', default=15, cast=int)
            self.locked_until = timezone.now() + timedelta(minutes=minutes)
        self.save(update_fields=['failed_login_attempts', 'locked_until', 'updated_at'])

    def reset_login_attempts(self):
        self.failed_login_attempts = 0
        self.locked_until = None
        self.save(update_fields=['failed_login_attempts', 'locked_until', 'updated_at'])
