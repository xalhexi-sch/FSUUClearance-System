from django.urls import path

from .views import (
    BrandedPasswordResetCompleteView,
    BrandedPasswordResetConfirmView,
    BrandedPasswordResetDoneView,
    BrandedPasswordResetView,
    change_password_view,
    login_view,
    logout_view,
)

app_name = 'accounts'

urlpatterns = [
    path('login/', login_view, name='login'),
    path('logout/', logout_view, name='logout'),
    path('change-password/', change_password_view, name='change_password'),
    path('password-reset/', BrandedPasswordResetView.as_view(), name='password_reset'),
    path('password-reset/done/', BrandedPasswordResetDoneView.as_view(), name='password_reset_done'),
    path('reset/<uidb64>/<token>/', BrandedPasswordResetConfirmView.as_view(), name='password_reset_confirm'),
    path('reset/done/', BrandedPasswordResetCompleteView.as_view(), name='password_reset_complete'),
]
