from django.contrib import messages
from django.contrib.auth import login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.views import PasswordResetCompleteView, PasswordResetConfirmView, PasswordResetDoneView, PasswordResetView
from django.shortcuts import redirect, render
from django.urls import reverse_lazy

from clearance.models import AuditLog

from .forms import FirstTimePasswordChangeForm, LoginForm


class BrandedPasswordResetView(PasswordResetView):
    template_name = 'accounts/password_reset.html'
    email_template_name = 'accounts/password_reset_email.txt'
    subject_template_name = 'accounts/password_reset_subject.txt'
    success_url = reverse_lazy('accounts:password_reset_done')


class BrandedPasswordResetDoneView(PasswordResetDoneView):
    template_name = 'accounts/password_reset_done.html'


class BrandedPasswordResetConfirmView(PasswordResetConfirmView):
    template_name = 'accounts/password_reset_confirm.html'
    success_url = reverse_lazy('accounts:password_reset_complete')


class BrandedPasswordResetCompleteView(PasswordResetCompleteView):
    template_name = 'accounts/password_reset_complete.html'


def login_view(request):
    if request.user.is_authenticated:
        return redirect('clearance:dashboard_redirect')

    form = LoginForm(request=request, data=request.POST or None)
    if request.method == 'POST' and form.is_valid():
        user = form.get_user()
        login(request, user)
        if not form.cleaned_data.get('remember_me'):
            request.session.set_expiry(0)
        AuditLog.log(user, 'login', {'username': user.username})
        messages.success(request, f'Welcome back, {user.get_full_name() or user.username}.')
        return redirect('clearance:dashboard_redirect')
    return render(request, 'accounts/login.html', {'form': form})


@login_required
def logout_view(request):
    AuditLog.log(request.user, 'logout', {'username': request.user.username})
    logout(request)
    messages.info(request, 'You have been logged out successfully.')
    return redirect('accounts:login')


@login_required
def change_password_view(request):
    form = FirstTimePasswordChangeForm(request.user, request.POST or None)
    if request.method == 'POST' and form.is_valid():
        user = form.save()
        user.must_change_password = False
        user.save(update_fields=['must_change_password', 'updated_at'])
        AuditLog.log(user, 'password_change', {'forced': True})
        messages.success(request, 'Password updated successfully.')
        return redirect('clearance:dashboard_redirect')
    return render(request, 'accounts/change_password.html', {'form': form})
