from django.contrib import admin

from .models import AuditLog, ClearanceItem, ClearanceRequest, Office, Semester, Student


@admin.register(Office)
class OfficeAdmin(admin.ModelAdmin):
    list_display = ('office_name', 'is_active')
    search_fields = ('office_name',)
    list_filter = ('is_active',)


@admin.register(Semester)
class SemesterAdmin(admin.ModelAdmin):
    list_display = ('semester_name', 'start_date', 'end_date', 'is_active')
    list_filter = ('is_active',)


class ClearanceItemInline(admin.TabularInline):
    model = ClearanceItem
    extra = 0


@admin.register(ClearanceRequest)
class ClearanceRequestAdmin(admin.ModelAdmin):
    list_display = ('student', 'semester', 'overall_status', 'created_at', 'completed_at')
    list_filter = ('overall_status', 'semester')
    search_fields = ('student__full_name', 'student__student_id')
    inlines = [ClearanceItemInline]


@admin.register(Student)
class StudentAdmin(admin.ModelAdmin):
    list_display = ('student_id', 'full_name', 'program', 'year_level', 'email_address')
    search_fields = ('student_id', 'full_name', 'program')
    list_filter = ('year_level', 'program')


@admin.register(AuditLog)
class AuditLogAdmin(admin.ModelAdmin):
    list_display = ('user', 'action', 'timestamp')
    list_filter = ('action',)
    search_fields = ('user__username', 'action')
