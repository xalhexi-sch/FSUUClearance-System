from django.conf import settings


def global_settings(request):
    return {'SITE_NAME': getattr(settings, 'SITE_NAME', 'FSUU Student Clearance System')}
