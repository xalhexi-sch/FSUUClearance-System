from django import forms

from .models import ClearanceItem, Office, Semester


class StyledModelForm(forms.ModelForm):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field in self.fields.values():
            base_class = 'form-select' if isinstance(field.widget, forms.Select) else 'form-control'
            field.widget.attrs['class'] = f"{field.widget.attrs.get('class', '')} {base_class}".strip()


class ClearanceActionForm(StyledModelForm):
    class Meta:
        model = ClearanceItem
        fields = ['status', 'remarks']
        widgets = {
            'status': forms.Select(),
            'remarks': forms.Textarea(attrs={'rows': 3}),
        }


class BulkApprovalForm(forms.Form):
    item_ids = forms.CharField(widget=forms.HiddenInput)
    remarks = forms.CharField(required=False, widget=forms.Textarea(attrs={'rows': 3, 'class': 'form-control'}))


class ReportFilterForm(forms.Form):
    semester = forms.ModelChoiceField(queryset=Semester.objects.all(), required=False, empty_label='All semesters')
    office = forms.ModelChoiceField(queryset=Office.objects.filter(is_active=True), required=False, empty_label='All offices')
    program = forms.CharField(required=False)
    year_level = forms.IntegerField(required=False, min_value=1, max_value=5)

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field in self.fields.values():
            if isinstance(field.widget, forms.Select):
                field.widget.attrs['class'] = 'form-select'
            else:
                field.widget.attrs['class'] = 'form-control'
