import random
from datetime import date, timedelta

from django.contrib.auth.hashers import make_password
from django.core.management.base import BaseCommand
from django.db import transaction

from accounts.models import CustomUser
from clearance.models import ClearanceItem, ClearanceRequest, Office, Semester, Student
from clearance.utils import create_clearance_for_student


PROGRAMS = [
    'BS Computer Science', 'BS Information Technology', 'BS Accountancy', 'BS Psychology',
    'BS Nursing', 'BS Biology', 'BS Education', 'BS Criminology'
]
OFFICES = [
    'Library', 'Clinic', 'Cashier', 'Registrar', 'Guidance', 'Laboratory', 'Academic Program'
]


class Command(BaseCommand):
    help = 'Seeds the database with demo data for FSUU Student Clearance System.'

    @transaction.atomic
    def handle(self, *args, **options):
        CustomUser.objects.exclude(is_superuser=True).delete()
        Office.objects.all().delete()
        Semester.objects.all().delete()
        current_semester = Semester.objects.create(
            semester_name='1st Semester 2025-2026',
            start_date=date(2025, 8, 1),
            end_date=date(2025, 12, 15),
            is_active=True,
        )
        Semester.objects.create(
            semester_name='2nd Semester 2024-2025',
            start_date=date(2025, 1, 10),
            end_date=date(2025, 5, 28),
            is_active=False,
        )
        office_objects = [Office.objects.create(office_name=name, description=f'{name} clearance unit') for name in OFFICES]
        for index, office in enumerate(office_objects, start=1):
            for suffix in range(1, 3 if index <= 3 else 2):
                CustomUser.objects.create(
                    username=f'{office.office_name.lower().replace(" ", "")}{suffix}',
                    email=f'{office.office_name.lower().replace(" ", "")}{suffix}@fsuu.edu.ph',
                    password=make_password('Password123!'),
                    first_name=office.office_name,
                    last_name=f'Staff {suffix}',
                    role=CustomUser.ROLE_OFFICE_STAFF,
                    office=office,
                    must_change_password=False,
                )
        for idx in range(1, 4):
            CustomUser.objects.create(
                username=f'admin{idx}',
                email=f'admin{idx}@fsuu.edu.ph',
                password=make_password('Password123!'),
                first_name='Admin',
                last_name=f'User {idx}',
                role=CustomUser.ROLE_ADMIN,
                must_change_password=False,
            )
        CustomUser.objects.create_superuser(
            username='superadmin',
            email='superadmin@fsuu.edu.ph',
            password='Password123!',
            role=CustomUser.ROLE_SUPERADMIN,
            must_change_password=False,
        )
        staff_users = list(CustomUser.objects.filter(role=CustomUser.ROLE_OFFICE_STAFF))
        for number in range(1, 51):
            username = f'student{number:02d}'
            user = CustomUser.objects.create(
                username=username,
                email=f'{username}@fsuu.edu.ph',
                password=make_password('Password123!'),
                first_name='Student',
                last_name=str(number),
                role=CustomUser.ROLE_STUDENT,
                must_change_password=False,
            )
            student = Student.objects.create(
                student_id=f'2025-{number:04d}',
                user=user,
                full_name=f'Student {number:02d} FSUU',
                program=random.choice(PROGRAMS),
                year_level=random.randint(1, 4),
                contact_number=f'09{random.randint(100000000, 999999999)}',
                email_address=user.email,
            )
            request = create_clearance_for_student(student, current_semester)
            for item in request.items.all():
                roll = random.random()
                if roll < 0.68:
                    item.status = ClearanceItem.STATUS_APPROVED
                    item.approved_by = random.choice(staff_users)
                    item.approved_at = request.created_at + timedelta(days=random.randint(1, 12))
                    item.remarks = 'Cleared after routine verification.'
                elif roll < 0.82:
                    item.status = ClearanceItem.STATUS_REJECTED
                    item.approved_by = random.choice(staff_users)
                    item.approved_at = request.created_at + timedelta(days=random.randint(1, 12))
                    item.remarks = 'Pending requirement submission.'
                item.save()
            request.refresh_status()
        self.stdout.write(self.style.SUCCESS('Demo data seeded successfully.'))
