from django.conf import settings
from django.db import models
from django.db.models import Count, Q
from django.urls import reverse
from django.utils import timezone


class Office(models.Model):
    office_id = models.BigAutoField(primary_key=True)
    office_name = models.CharField(max_length=120, unique=True)
    description = models.TextField(blank=True)
    is_active = models.BooleanField(default=True)

    class Meta:
        db_table = 'offices'
        ordering = ['office_name']

    def __str__(self):
        return self.office_name


class Semester(models.Model):
    semester_id = models.BigAutoField(primary_key=True)
    semester_name = models.CharField(max_length=120, unique=True)
    start_date = models.DateField()
    end_date = models.DateField()
    is_active = models.BooleanField(default=False)

    class Meta:
        db_table = 'semesters'
        ordering = ['-start_date']

    def __str__(self):
        return self.semester_name


class Student(models.Model):
    student_id = models.CharField(primary_key=True, max_length=20)
    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='student_profile')
    full_name = models.CharField(max_length=255)
    program = models.CharField(max_length=150)
    year_level = models.PositiveSmallIntegerField()
    contact_number = models.CharField(max_length=30, blank=True)
    email_address = models.EmailField()

    class Meta:
        db_table = 'students'
        ordering = ['full_name']

    def __str__(self):
        return f'{self.student_id} - {self.full_name}'


class ClearanceRequest(models.Model):
    STATUS_PENDING = 'Pending'
    STATUS_PARTIAL = 'Partially Cleared'
    STATUS_FULL = 'Fully Cleared'
    STATUS_CHOICES = [
        (STATUS_PENDING, 'Pending'),
        (STATUS_PARTIAL, 'Partially Cleared'),
        (STATUS_FULL, 'Fully Cleared'),
    ]

    request_id = models.BigAutoField(primary_key=True)
    student = models.ForeignKey(Student, on_delete=models.CASCADE, related_name='clearance_requests')
    semester = models.ForeignKey(Semester, on_delete=models.CASCADE, related_name='clearance_requests')
    overall_status = models.CharField(max_length=25, choices=STATUS_CHOICES, default=STATUS_PENDING)
    created_at = models.DateTimeField(auto_now_add=True)
    completed_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        db_table = 'clearance_requests'
        unique_together = ('student', 'semester')
        ordering = ['-created_at']

    def __str__(self):
        return f'{self.student.full_name} - {self.semester.semester_name}'

    @property
    def approved_count(self):
        return self.items.filter(status=ClearanceItem.STATUS_APPROVED).count()

    @property
    def rejected_count(self):
        return self.items.filter(status=ClearanceItem.STATUS_REJECTED).count()

    @property
    def total_items(self):
        return self.items.count()

    @property
    def progress_percent(self):
        total = self.total_items or 1
        return round((self.approved_count / total) * 100)

    def refresh_status(self, save=True):
        total = self.total_items
        approved = self.approved_count
        rejected = self.rejected_count
        if total and approved == total:
            self.overall_status = self.STATUS_FULL
            self.completed_at = timezone.now()
        elif approved > 0 or rejected > 0:
            self.overall_status = self.STATUS_PARTIAL
            self.completed_at = None
        else:
            self.overall_status = self.STATUS_PENDING
            self.completed_at = None
        if save:
            self.save(update_fields=['overall_status', 'completed_at'])
        return self.overall_status

    @classmethod
    def for_dashboard_metrics(cls, semester=None):
        queryset = cls.objects.all()
        if semester:
            queryset = queryset.filter(semester=semester)
        return queryset.aggregate(
            total_students=Count('request_id'),
            fully_cleared=Count('request_id', filter=Q(overall_status=cls.STATUS_FULL)),
            pending=Count('request_id', filter=~Q(overall_status=cls.STATUS_FULL)),
        )

    def get_absolute_url(self):
        return reverse('clearance:clearance_detail', args=[self.request_id])


class ClearanceItem(models.Model):
    STATUS_PENDING = 'Pending'
    STATUS_APPROVED = 'Approved'
    STATUS_REJECTED = 'Rejected'
    STATUS_CHOICES = [
        (STATUS_PENDING, 'Pending'),
        (STATUS_APPROVED, 'Approved'),
        (STATUS_REJECTED, 'Rejected'),
    ]

    item_id = models.BigAutoField(primary_key=True)
    request = models.ForeignKey(ClearanceRequest, on_delete=models.CASCADE, related_name='items')
    office = models.ForeignKey(Office, on_delete=models.CASCADE, related_name='clearance_items')
    status = models.CharField(max_length=12, choices=STATUS_CHOICES, default=STATUS_PENDING)
    approved_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True, related_name='approved_items')
    approved_at = models.DateTimeField(null=True, blank=True)
    remarks = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'clearance_items'
        unique_together = ('request', 'office')
        ordering = ['office__office_name']

    def __str__(self):
        return f'{self.request.student.full_name} - {self.office.office_name}'

    def process(self, status, user, remarks=''):
        self.status = status
        self.approved_by = user
        self.approved_at = timezone.now()
        self.remarks = remarks
        self.save(update_fields=['status', 'approved_by', 'approved_at', 'remarks', 'updated_at'])
        self.request.refresh_status()


class AuditLog(models.Model):
    log_id = models.BigAutoField(primary_key=True)
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='audit_logs')
    action = models.CharField(max_length=100)
    details = models.JSONField(default=dict, blank=True)
    timestamp = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'audit_logs'
        ordering = ['-timestamp']

    def __str__(self):
        return f'{self.user.username} - {self.action}'

    @classmethod
    def log(cls, user, action, details=None):
        return cls.objects.create(user=user, action=action, details=details or {})
