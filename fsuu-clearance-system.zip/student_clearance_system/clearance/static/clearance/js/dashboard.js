function parseJsonScript(id) {
    const element = document.getElementById(id);
    if (!element) return null;
    return JSON.parse(element.textContent);
}

document.addEventListener('DOMContentLoaded', () => {
    const officeStats = parseJsonScript('office-stats-data');
    if (officeStats && document.getElementById('officeChart')) {
        new Chart(document.getElementById('officeChart'), {
            type: 'bar',
            data: {
                labels: officeStats.map(item => item.office__office_name),
                datasets: [{ label: 'Processed items', data: officeStats.map(item => item.total_processed) }],
            },
            options: { responsive: true, plugins: { legend: { display: false } } },
        });
    }
    const trends = parseJsonScript('trend-data');
    if (trends && document.getElementById('trendChart')) {
        new Chart(document.getElementById('trendChart'), {
            type: 'line',
            data: {
                labels: trends.map(item => item.semester__semester_name),
                datasets: [{ label: 'Fully cleared', data: trends.map(item => item.fully_cleared) }],
            },
            options: { responsive: true },
        });
    }
});

function toggleAllRows(master) {
    document.querySelectorAll('.row-selector').forEach(checkbox => checkbox.checked = master.checked);
}

function prepareBulkApproval() {
    const selected = Array.from(document.querySelectorAll('.row-selector:checked')).map(item => item.value);
    if (!selected.length) {
        alert('Select at least one clearance item to bulk approve.');
        return false;
    }
    document.getElementById('bulkItemIds').value = selected.join(',');
    return true;
}
