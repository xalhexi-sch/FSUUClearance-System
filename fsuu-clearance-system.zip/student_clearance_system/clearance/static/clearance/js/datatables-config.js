document.addEventListener("DOMContentLoaded", () => console.log("Table enhancements ready."));
