from django import template

register = template.Library()


@register.filter
def status_badge(value):
    mapping = {
        'Pending': 'warning',
        'Approved': 'success',
        'Rejected': 'danger',
        'Partially Cleared': 'info',
        'Fully Cleared': 'success',
    }
    return mapping.get(value, 'secondary')
