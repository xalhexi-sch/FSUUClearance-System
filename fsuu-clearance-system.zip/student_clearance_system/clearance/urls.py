from django.urls import path

from . import views

app_name = 'clearance'

urlpatterns = [
    path('', views.dashboard_redirect, name='dashboard_redirect'),
    path('student/dashboard/', views.student_dashboard, name='student_dashboard'),
    path('office/dashboard/', views.office_dashboard, name='office_dashboard'),
    path('management/dashboard/', views.admin_dashboard, name='admin_dashboard'),
    path('clearance/<int:pk>/', views.clearance_detail, name='clearance_detail'),
    path('clearance/item/<int:pk>/update/', views.update_clearance_item, name='update_clearance_item'),
    path('clearance/bulk-approve/', views.bulk_approve, name='bulk_approve'),
    path('reports/', views.reports_view, name='reports'),
    path('api/office-activity/', views.office_activity_api, name='office_activity_api'),
]
