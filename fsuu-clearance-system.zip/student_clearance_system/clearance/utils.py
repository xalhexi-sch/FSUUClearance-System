from django.conf import settings
from django.core.mail import send_mail
from django.db import transaction
from django.db.models import Avg, Count, DurationField, ExpressionWrapper, F, Q

from .models import ClearanceItem, ClearanceRequest, Office, Semester


def create_clearance_for_student(student, semester=None):
    semester = semester or Semester.objects.filter(is_active=True).first()
    if semester is None:
        raise ValueError('An active semester is required before creating clearance requests.')
    with transaction.atomic():
        request, created = ClearanceRequest.objects.get_or_create(student=student, semester=semester)
        if created:
            for office in Office.objects.filter(is_active=True):
                ClearanceItem.objects.create(request=request, office=office)
        request.refresh_status()
        return request


def send_clearance_update_email(clearance_item):
    student = clearance_item.request.student
    subject = f'FSUU Clearance Update - {clearance_item.office.office_name}'
    message = (
        f"Dear {student.full_name}\n\n"
        f"Your clearance with {clearance_item.office.office_name} has been updated to {clearance_item.status}.\n"
        f"Remarks: {clearance_item.remarks or 'No remarks provided.'}\n\n"
        f"Please log in to {settings.SITE_NAME} for more details."
    )
    send_mail(subject, message, settings.DEFAULT_FROM_EMAIL, [student.email_address], fail_silently=True)


def office_performance_queryset(semester=None):
    queryset = ClearanceItem.objects.filter(status__in=[ClearanceItem.STATUS_APPROVED, ClearanceItem.STATUS_REJECTED])
    if semester:
        queryset = queryset.filter(request__semester=semester)
    duration_expr = ExpressionWrapper(F('approved_at') - F('request__created_at'), output_field=DurationField())
    return queryset.values('office__office_name').annotate(
        total_processed=Count('item_id'),
        approved_count=Count('item_id', filter=Q(status=ClearanceItem.STATUS_APPROVED)),
        rejected_count=Count('item_id', filter=Q(status=ClearanceItem.STATUS_REJECTED)),
        average_processing_time=Avg(duration_expr),
    ).order_by('office__office_name')
