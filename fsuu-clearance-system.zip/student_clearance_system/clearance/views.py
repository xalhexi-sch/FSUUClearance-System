from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core.paginator import Paginator
from django.db.models import Count, Prefetch, Q
from django.http import Http404, JsonResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_POST

from .forms import BulkApprovalForm, ClearanceActionForm, ReportFilterForm
from .models import AuditLog, ClearanceItem, ClearanceRequest, Semester
from .utils import office_performance_queryset, send_clearance_update_email


@login_required
def dashboard_redirect(request):
    role = request.user.role
    if role == request.user.ROLE_STUDENT:
        return redirect('clearance:student_dashboard')
    if role == request.user.ROLE_OFFICE_STAFF:
        return redirect('clearance:office_dashboard')
    return redirect('clearance:admin_dashboard')


@login_required
def student_dashboard(request):
    if request.user.role != request.user.ROLE_STUDENT:
        raise Http404()
    active_semester = Semester.objects.filter(is_active=True).first()
    clearance_request = (
        ClearanceRequest.objects.filter(student=request.user.student_profile, semester=active_semester)
        .prefetch_related('items__office', 'items__approved_by')
        .first()
    )
    recent_logs = AuditLog.objects.filter(
        details__student_id=request.user.student_profile.student_id
    )[:8]
    return render(request, 'clearance/student_dashboard.html', {
        'active_semester': active_semester,
        'clearance_request': clearance_request,
        'recent_logs': recent_logs,
    })


@login_required
def office_dashboard(request):
    if request.user.role != request.user.ROLE_OFFICE_STAFF:
        raise Http404()
    office = request.user.office
    queryset = ClearanceItem.objects.filter(office=office).select_related(
        'request__student', 'request__semester', 'approved_by'
    )
    search = request.GET.get('search', '').strip()
    program = request.GET.get('program', '').strip()
    year_level = request.GET.get('year_level', '').strip()
    status = request.GET.get('status', '').strip()
    if search:
        queryset = queryset.filter(
            Q(request__student__full_name__icontains=search)
            | Q(request__student__student_id__icontains=search)
        )
    if program:
        queryset = queryset.filter(request__student__program__icontains=program)
    if year_level:
        queryset = queryset.filter(request__student__year_level=year_level)
    if status:
        queryset = queryset.filter(status=status)

    paginator = Paginator(queryset.order_by('status', 'request__student__full_name'), 20)
    page_obj = paginator.get_page(request.GET.get('page'))
    recent_activity = AuditLog.objects.filter(user__office=office, action__in=['approve', 'reject'])[:10]
    context = {
        'page_obj': page_obj,
        'office': office,
        'recent_activity': recent_activity,
        'status_choices': ClearanceItem.STATUS_CHOICES,
        'bulk_form': BulkApprovalForm(),
    }
    return render(request, 'clearance/office_dashboard.html', context)


@login_required
def admin_dashboard(request):
    if request.user.role not in [request.user.ROLE_ADMIN, request.user.ROLE_SUPERADMIN]:
        raise Http404()
    semester = Semester.objects.filter(is_active=True).first()
    metrics = ClearanceRequest.for_dashboard_metrics(semester)
    office_stats = list(office_performance_queryset(semester))
    recent_requests = ClearanceRequest.objects.select_related('student', 'semester').order_by('-created_at')[:10]
    trends = list(
        ClearanceRequest.objects.values('semester__semester_name')
        .annotate(total=Count('request_id'), fully_cleared=Count('request_id', filter=Q(overall_status=ClearanceRequest.STATUS_FULL)))
        .order_by('semester__start_date')
    )
    return render(request, 'clearance/admin_dashboard.html', {
        'semester': semester,
        'metrics': metrics,
        'office_stats': office_stats,
        'recent_requests': recent_requests,
        'trends': trends,
    })


@login_required
def clearance_detail(request, pk):
    clearance_request = get_object_or_404(
        ClearanceRequest.objects.select_related('student', 'semester').prefetch_related('items__office', 'items__approved_by'),
        pk=pk,
    )
    if request.user.role == request.user.ROLE_STUDENT and clearance_request.student.user != request.user:
        raise Http404()
    if request.user.role == request.user.ROLE_OFFICE_STAFF and not clearance_request.items.filter(office=request.user.office).exists():
        raise Http404()
    return render(request, 'clearance/clearance_detail.html', {'clearance_request': clearance_request})


@login_required
@require_POST
def update_clearance_item(request, pk):
    item = get_object_or_404(ClearanceItem.objects.select_related('request__student', 'office'), pk=pk)
    if request.user.role == request.user.ROLE_OFFICE_STAFF and item.office != request.user.office:
        raise Http404()
    if request.user.role == request.user.ROLE_STUDENT:
        raise Http404()
    form = ClearanceActionForm(request.POST, instance=item)
    if form.is_valid():
        updated_item = form.save(commit=False)
        updated_item.approved_by = request.user
        from django.utils import timezone
        updated_item.approved_at = timezone.now()
        updated_item.save()
        updated_item.request.refresh_status()
        AuditLog.log(request.user, updated_item.status.lower(), {
            'student_id': updated_item.request.student.student_id,
            'office': updated_item.office.office_name,
            'status': updated_item.status,
        })
        send_clearance_update_email(updated_item)
        messages.success(request, f'{updated_item.office.office_name} clearance updated successfully.')
    else:
        messages.error(request, 'Please correct the form errors and try again.')
    if request.user.role == request.user.ROLE_OFFICE_STAFF:
        return redirect('clearance:office_dashboard')
    return redirect('clearance:clearance_detail', pk=item.request_id)


@login_required
@require_POST
def bulk_approve(request):
    if request.user.role != request.user.ROLE_OFFICE_STAFF:
        raise Http404()
    item_ids = [item_id for item_id in request.POST.get('item_ids', '').split(',') if item_id]
    remarks = request.POST.get('remarks', '').strip()
    items = ClearanceItem.objects.filter(item_id__in=item_ids, office=request.user.office)
    updated = 0
    for item in items:
        item.process(ClearanceItem.STATUS_APPROVED, request.user, remarks)
        AuditLog.log(request.user, 'approve', {
            'student_id': item.request.student.student_id,
            'office': item.office.office_name,
            'bulk': True,
        })
        send_clearance_update_email(item)
        updated += 1
    messages.success(request, f'{updated} clearance item(s) approved successfully.')
    return redirect('clearance:office_dashboard')


@login_required
def reports_view(request):
    if request.user.role not in [request.user.ROLE_ADMIN, request.user.ROLE_SUPERADMIN]:
        raise Http404()
    form = ReportFilterForm(request.GET or None)
    queryset = ClearanceRequest.objects.select_related('student', 'semester').prefetch_related(
        Prefetch('items', queryset=ClearanceItem.objects.select_related('office'))
    )
    if form.is_valid():
        semester = form.cleaned_data.get('semester')
        office = form.cleaned_data.get('office')
        program = form.cleaned_data.get('program')
        year_level = form.cleaned_data.get('year_level')
        if semester:
            queryset = queryset.filter(semester=semester)
        if office:
            queryset = queryset.filter(items__office=office)
        if program:
            queryset = queryset.filter(student__program__icontains=program)
        if year_level:
            queryset = queryset.filter(student__year_level=year_level)
    queryset = queryset.distinct().order_by('student__full_name')
    paginator = Paginator(queryset, 20)
    page_obj = paginator.get_page(request.GET.get('page'))
    return render(request, 'clearance/reports.html', {'form': form, 'page_obj': page_obj})


@login_required
def office_activity_api(request):
    if request.user.role not in [request.user.ROLE_ADMIN, request.user.ROLE_SUPERADMIN]:
        raise Http404()
    semester = Semester.objects.filter(is_active=True).first()
    data = list(office_performance_queryset(semester))
    return JsonResponse(data, safe=False)
