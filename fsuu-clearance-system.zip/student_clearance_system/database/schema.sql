CREATE TABLE offices (
    office_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    office_name VARCHAR(120) NOT NULL UNIQUE,
    description LONGTEXT NULL,
    is_active BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE semesters (
    semester_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    semester_name VARCHAR(120) NOT NULL UNIQUE,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    is_active BOOLEAN NOT NULL DEFAULT FALSE
);

CREATE TABLE custom_user (
    user_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    password VARCHAR(128) NOT NULL,
    last_login DATETIME NULL,
    is_superuser BOOLEAN NOT NULL DEFAULT FALSE,
    username VARCHAR(150) NOT NULL UNIQUE,
    first_name VARCHAR(150) NOT NULL,
    last_name VARCHAR(150) NOT NULL,
    email VARCHAR(254) NOT NULL,
    is_staff BOOLEAN NOT NULL DEFAULT FALSE,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    date_joined DATETIME NOT NULL,
    role VARCHAR(20) NOT NULL,
    office_id BIGINT NULL,
    must_change_password BOOLEAN NOT NULL DEFAULT TRUE,
    failed_login_attempts SMALLINT UNSIGNED NOT NULL DEFAULT 0,
    locked_until DATETIME NULL,
    created_at DATETIME NOT NULL,
    updated_at DATETIME NOT NULL,
    CONSTRAINT fk_custom_user_office FOREIGN KEY (office_id) REFERENCES offices (office_id)
);

CREATE TABLE students (
    student_id VARCHAR(20) PRIMARY KEY,
    user_id BIGINT NOT NULL UNIQUE,
    full_name VARCHAR(255) NOT NULL,
    program VARCHAR(150) NOT NULL,
    year_level SMALLINT UNSIGNED NOT NULL,
    contact_number VARCHAR(30) NULL,
    email_address VARCHAR(254) NOT NULL,
    CONSTRAINT fk_students_user FOREIGN KEY (user_id) REFERENCES custom_user (user_id)
);

CREATE TABLE clearance_requests (
    request_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    student_id VARCHAR(20) NOT NULL,
    semester_id BIGINT NOT NULL,
    overall_status VARCHAR(25) NOT NULL DEFAULT 'Pending',
    created_at DATETIME NOT NULL,
    completed_at DATETIME NULL,
    UNIQUE KEY unique_student_semester (student_id, semester_id),
    CONSTRAINT fk_requests_student FOREIGN KEY (student_id) REFERENCES students (student_id),
    CONSTRAINT fk_requests_semester FOREIGN KEY (semester_id) REFERENCES semesters (semester_id)
);

CREATE TABLE clearance_items (
    item_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    request_id BIGINT NOT NULL,
    office_id BIGINT NOT NULL,
    status VARCHAR(12) NOT NULL DEFAULT 'Pending',
    approved_by_id BIGINT NULL,
    approved_at DATETIME NULL,
    remarks LONGTEXT NULL,
    created_at DATETIME NOT NULL,
    updated_at DATETIME NOT NULL,
    UNIQUE KEY unique_request_office (request_id, office_id),
    CONSTRAINT fk_items_request FOREIGN KEY (request_id) REFERENCES clearance_requests (request_id),
    CONSTRAINT fk_items_office FOREIGN KEY (office_id) REFERENCES offices (office_id),
    CONSTRAINT fk_items_approved_by FOREIGN KEY (approved_by_id) REFERENCES custom_user (user_id)
);

CREATE TABLE audit_logs (
    log_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT NOT NULL,
    action VARCHAR(100) NOT NULL,
    details JSON NOT NULL,
    timestamp DATETIME NOT NULL,
    CONSTRAINT fk_audit_logs_user FOREIGN KEY (user_id) REFERENCES custom_user (user_id)
);
