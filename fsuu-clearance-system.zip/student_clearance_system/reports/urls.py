from django.urls import path

from . import views

app_name = 'reports'

urlpatterns = [
    path('students/excel/', views.export_students_excel, name='export_students_excel'),
    path('students/pdf/', views.export_students_pdf, name='export_students_pdf'),
    path('office-performance/excel/', views.export_office_performance_excel, name='export_office_performance_excel'),
    path('clearance-form/<int:pk>/', views.export_clearance_form_pdf, name='export_clearance_form_pdf'),
]
