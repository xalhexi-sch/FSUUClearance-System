from io import BytesIO

from openpyxl import Workbook
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle


def build_excel(headers, rows, sheet_name='Report'):
    workbook = Workbook()
    worksheet = workbook.active
    worksheet.title = sheet_name
    worksheet.append(headers)
    for row in rows:
        worksheet.append(row)
    for column in worksheet.columns:
        max_length = max(len(str(cell.value or '')) for cell in column)
        worksheet.column_dimensions[column[0].column_letter].width = min(max_length + 2, 35)
    return workbook


def build_pdf(title, headers, rows):
    buffer = BytesIO()
    document = SimpleDocTemplate(buffer, pagesize=landscape(A4), topMargin=36, leftMargin=24, rightMargin=24)
    styles = getSampleStyleSheet()
    story = [Paragraph(f'<b>Father Saturnino Urios University</b>', styles['Title']), Paragraph(title, styles['Heading2']), Spacer(1, 12)]
    table_data = [headers] + rows
    table = Table(table_data, repeatRows=1)
    table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#1e3a8a')),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
        ('GRID', (0, 0), (-1, -1), 0.5, colors.grey),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.whitesmoke, colors.HexColor('#eef2ff')]),
        ('PADDING', (0, 0), (-1, -1), 6),
    ]))
    story.append(table)
    document.build(story)
    buffer.seek(0)
    return buffer
