from django.contrib.auth.decorators import login_required
from django.http import Http404, HttpResponse

from clearance.forms import ReportFilterForm
from clearance.models import ClearanceItem, ClearanceRequest

from .utils import build_excel, build_pdf


def _filtered_requests(request):
    form = ReportFilterForm(request.GET or None)
    queryset = ClearanceRequest.objects.select_related('student', 'semester').prefetch_related('items__office')
    if form.is_valid():
        semester = form.cleaned_data.get('semester')
        office = form.cleaned_data.get('office')
        program = form.cleaned_data.get('program')
        year_level = form.cleaned_data.get('year_level')
        if semester:
            queryset = queryset.filter(semester=semester)
        if office:
            queryset = queryset.filter(items__office=office)
        if program:
            queryset = queryset.filter(student__program__icontains=program)
        if year_level:
            queryset = queryset.filter(student__year_level=year_level)
    return queryset.distinct(), form


@login_required
def export_students_excel(request):
    if request.user.role not in [request.user.ROLE_ADMIN, request.user.ROLE_SUPERADMIN]:
        raise Http404()
    queryset, _ = _filtered_requests(request)
    headers = ['Student ID', 'Name', 'Program', 'Year', 'Semester', 'Overall Status']
    rows = [[item.student.student_id, item.student.full_name, item.student.program, item.student.year_level, item.semester.semester_name, item.overall_status] for item in queryset]
    workbook = build_excel(headers, rows, 'Students')
    response = HttpResponse(content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
    response['Content-Disposition'] = 'attachment; filename="fsuu-student-clearance-report.xlsx"'
    workbook.save(response)
    return response


@login_required
def export_students_pdf(request):
    if request.user.role not in [request.user.ROLE_ADMIN, request.user.ROLE_SUPERADMIN]:
        raise Http404()
    queryset, _ = _filtered_requests(request)
    headers = ['Student ID', 'Name', 'Program', 'Year', 'Semester', 'Overall Status']
    rows = [[item.student.student_id, item.student.full_name, item.student.program, str(item.student.year_level), item.semester.semester_name, item.overall_status] for item in queryset]
    pdf = build_pdf('Student Clearance Summary', headers, rows)
    response = HttpResponse(pdf.read(), content_type='application/pdf')
    response['Content-Disposition'] = 'attachment; filename="fsuu-student-clearance-report.pdf"'
    return response


@login_required
def export_office_performance_excel(request):
    if request.user.role not in [request.user.ROLE_ADMIN, request.user.ROLE_SUPERADMIN]:
        raise Http404()
    headers = ['Office', 'Student', 'Status', 'Approved At', 'Remarks']
    items = ClearanceItem.objects.select_related('office', 'request__student').order_by('office__office_name', 'request__student__full_name')
    rows = [[item.office.office_name, item.request.student.full_name, item.status, item.approved_at.strftime('%Y-%m-%d %H:%M') if item.approved_at else '', item.remarks] for item in items]
    workbook = build_excel(headers, rows, 'Office Performance')
    response = HttpResponse(content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
    response['Content-Disposition'] = 'attachment; filename="fsuu-office-performance.xlsx"'
    workbook.save(response)
    return response


@login_required
def export_clearance_form_pdf(request, pk):
    clearance_request = ClearanceRequest.objects.select_related('student', 'semester').prefetch_related('items__office').get(pk=pk)
    if request.user.role == request.user.ROLE_STUDENT and clearance_request.student.user != request.user:
        raise Http404()
    if clearance_request.overall_status != ClearanceRequest.STATUS_FULL:
        raise Http404()
    headers = ['Office', 'Status', 'Date Approved', 'Remarks']
    rows = [[item.office.office_name, item.status, item.approved_at.strftime('%Y-%m-%d %H:%M') if item.approved_at else '', item.remarks or '—'] for item in clearance_request.items.all()]
    pdf = build_pdf(f'Official Clearance Form - {clearance_request.student.full_name}', headers, rows)
    response = HttpResponse(pdf.read(), content_type='application/pdf')
    response['Content-Disposition'] = f'attachment; filename="clearance-{clearance_request.student.student_id}.pdf"'
    return response
