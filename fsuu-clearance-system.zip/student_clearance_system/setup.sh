#!/usr/bin/env bash
set -e
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp -n .env.example .env || true
python manage.py makemigrations
python manage.py migrate
python manage.py seed_demo_data
printf '
Setup complete. Update .env for MySQL and run: python manage.py runserver
'
